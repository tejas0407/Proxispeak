# ProxiSpeak Submission Pack

**Project:** ProxiSpeak: Geospatial Proximity Audio Ecosystem  
**Reference:** ITS/WEB/1213  
**Project period:** 10 October–10 November 2026

## Included

- `source-package/ProxiSpeak_Source_Code.zip` — application source without installed dependencies, local secrets, or generated output.
- `docs/PROJECT_DOCUMENTATION.md` — technical overview, system design, API and event summary, and setup.
- `docs/DEMO_GUIDE.md` — steps for a two-browser demonstration.
- `docs/VALIDATION_NOTES.md` — completed checks and known validation limits.
- `report/ProxiSpeak_Project_Report.docx` — formal project report.
- `presentation/ProxiSpeak_Final_Review.pptx` — editable presentation deck.

Machine-learning model evaluation is not applicable because this project has no trained model. Functional checks and the external-network audio limitation are documented in the validation notes.
